from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse,HttpResponseRedirect,Http404
from django.urls import reverse
from .models import Questions,Choices
from django.template import loader
# Create your views here.

def index(request):
    latest_question_list = Questions.objects.order_by('-question_time')[:5]
    template = loader.get_template('polls/index.html')
    context = {
        'latest_question_list': latest_question_list,
    }
    return HttpResponse(template.render(context, request))

def details(request, question_id):
    question = get_object_or_404(Questions, pk=question_id)
    return render(request, 'polls/details.html', {'question': question})

def result(request, question_id):
    question = get_object_or_404(Questions, pk=question_id)
    return render(request, 'polls/results.html', {'question': question})


def vote(request, question_id):
    question = get_object_or_404(Questions, pk=question_id)
    try:
        select_choice=question.choices_set.get(pk=request.POST['choice'])
    except(KeyError, Choices.DoesNotExist):   # 发生choice未找到异常时，重新返回表单页面，并给出提示信息
        return render(request, 'polls/details.html', {
            'question':question,
            'error_message':"You didn't select a choice.",
        })
    else:
        select_choice.votes += 1
        select_choice.save() # 成功处理数据后，自动跳转到结果页面，防止用户连续多次提交。

        return HttpResponseRedirect(reverse('polls:result', args=(question.id,)))



