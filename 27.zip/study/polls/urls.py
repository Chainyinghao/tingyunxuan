from django.conf.urls import re_path
from . import views as app_view

app_name = 'polls'

urlpatterns = [

    re_path(r'^$', app_view.index, name='index'),
    re_path(r'^(?P<question_id>[0-9]+)/$', app_view.details, name='details'),
    re_path(r'^(?P<question_id>[0-9]+)/result/$', app_view.result, name='result'),
    re_path(r'^(?P<question_id>[0-9]+)/votes/$', app_view.vote, name="votes"),


]