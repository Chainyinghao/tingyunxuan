from django.db import models
from django.utils import timezone
import datetime

# Create your models here.


class Questions(models.Model):
    question_text = models.CharField(max_length=300)
    question_time = models.DateTimeField("data published")

    def __str__(self):
        return self.question_text

    def was_published_recently(self):
        return self.question_time >= timezone.now() - datetime.timedelta(days=1)

class Choices(models.Model):
    question = models.ForeignKey(Questions, on_delete=models.CASCADE)
    choice = models.CharField(max_length=300)
    votes = models.IntegerField(default=0)

    def __str__(self):
        return self.choice


