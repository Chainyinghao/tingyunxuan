from django.http import HttpResponse
import time



