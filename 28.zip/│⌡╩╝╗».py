# 创建指针
class student:
    def __init__(self):
        self.name = ''
        self.score = 0
        self.no = 0
        self.next = None


# 创建链表

head = student()
head.next = None
ptr = head
select = 0

while select != 2:
    print('（1）新增  （2）离开 =>')
    try:
        select = int(input('请输入一个选项：'))
    except:
        print('输入错误')
        print('请重新输入')
    if select == 1:
        new_data = student()
        new_data.name = input('姓名：')
        new_data.score = input('成绩：')
        new_data.no = input('学号：')
        ptr.next = new_data
        new_data.next = None
        ptr = ptr.next

# 遍历单向链表

ptr = head.next
while ptr != None:
    print("学号：{}，\t姓名：{}，\t成绩：{}".format(ptr.no, ptr.name, ptr.score))
    ptr = ptr.next
