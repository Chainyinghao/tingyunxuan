import sys


# 创建指针
class employee:
    def __init__(self):
        self.num = 0
        self.salary = 0
        self.name = ''
        self.next = None


# 查找节点
def findnode(head, num):
    ptr = head

    while ptr != None:
        if ptr.num == num:
            return ptr
        ptr = ptr.next
    return ptr


# 插入节点
def insertnode(head, ptr, num, salary, name):
    InsertNode = employee()
    if not InsertNode:
        return None
    InsertNode.num = num
    InsertNode.salary = salary
    InsertNode.name = name
    InsertNode.next = None
    if ptr == None:
        InsertNode.next = head
        return InsertNode
    else:
        if ptr.next == None:
            ptr.next = InsertNode
        else:
            InsertNode.next = ptr.next
            ptr.next = InsertNode
    return head


position = 0
data = [[1001, 32367], [1002, 24388], [1003, 27556],[1007, 31299],
        [1012, 42660], [1014, 25676], [1018, 44145], [1043, 52182],
        [1031, 32758], [1037, 34245], [1041, 51531], [1057, 63612]]

namedata = ['Allen', 'Bob', 'Scott', 'Marry', 'John', 'Mark', 'Jack', 'Lisa',
            'Amy', 'Hanson', 'Ricky', 'Jasica']
print('员工编号  薪水  员工编号  薪水    员工编号  薪水    员工编号  薪水')
print('--------------------------------------------------------------')
for i in range(3):
    for j in range(4):
        print('{:4}     ${:5}'.format(data[j * 3 + i][0], data[j * 3 + i][1]), end='\t')
    print()

print('--------------------------------------------------------------')

# 创建头节点
head = employee()
head.next = None
if not head:
    print('Error！！！内存分配失败！\n')
    sys.exit(1)
head.num = data[0][0]
head.name = namedata[0][0]
head.salary = data[0][1]
head.next = None
ptr = head

# 建立链表
for i in range(1, 12):
    newnode = employee()
    newnode.next = None
    newnode.num = data[i][0]
    newnode.salary = data[i][1]
    newnode.name = namedata[i]
    ptr.next = newnode
    ptr = ptr.next

while (True):
    print('请输入要插入其后的员工编号,如果没有此编号则默认插入在头部，')
    position = int(input('结束请输入-1：'))
    if position == -1:
        break
    else:
        ptr = findnode(head, position)
        new_num = int(input('请输入员工编号：'))
        new_salary = int(input('请输入薪水：'))
        new_name = input('请输入姓名：')
        head = insertnode(head, ptr, new_num, new_salary, new_name)
    print()

# 遍历单向链表

ptr = head
print("员工编号\t姓名\t\t薪水")
print('=======================')
while ptr != None:
    print('{:4}\t{:6}\t\t{:5}'.format(ptr.num, ptr.name, ptr.salary))
    ptr = ptr.next
